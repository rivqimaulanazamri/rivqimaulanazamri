<?php

 require_once "app/Mhsw.php";
 $mhsw = new Mhsw();
 $rows = $mhsw->tampil(); 
 if(isset($_GET['cari'])) $vcari =$_GET['cari'];
else $vcari ='';
if(isset($_GET['id'])) $vid =$_GET['id'];
else $vid ='';
if(isset($_GET['nim'])) $vnim =$_GET['nim'];
else $vnim ='';
if(isset($_GET['nama'])) $vnama =$_GET['nama'];
else $vnama ='';
if(isset($_GET['alamat'])) $valamat =$_GET['alamat'];
else $valamat ='';

 if($vcari=="cari")  {
    $rows = $mhsw->tampil_cari($vnim,$vnama,$valamat);
 }
 ?>
 
 <form action="?" method="get">
<table>
    <tr><td>NIM</td><td>:</td><td>
        <input type="hidden" name="id" value="<?php echo $vid; ?>" /><input type="text" name="nim" value="<?php echo $vnim; ?>" /></td></tr>
    <tr><td>NAMA</td><td>:</td><td><input type="text" name="nama" value="<?php echo $vnama; ?>"/></td></tr>
    <tr><td>ALAMAT</td><td>:</td><td><input type="text" name="alamat" value="<?php echo $valamat; ?>"/></td></tr>
    <tr><td></td><td></td><td>
    <input type="submit" name='simpan' value="simpan"/>
    <input type="submit" name='update' value="update"/>
    <input type="submit" name='reset' value="reset"/>
    <input type="submit" name='cari' value="cari"/>
    </td></tr>
</table>
</form>	
  
 <table="1px">
 <tr>
 <td>NO</td>
 <td>NIM</td>
 <td>NAMA</td>
 <td>ALAMAT</td>
 </tr>

 <?php foreach ($rows as $row) { ?>
 <tr>
 <td><?php echo $row['mhsw_id']; ?></td>
 <td><?php echo $row['mhsw_nim']; ?></td>
 <td><?php echo $row['mhsw_nama']; ?></td>
 <td><?php echo $row['mhsw_alamat']; ?></td>
    <td><a href="?mhsw_id=<?php echo $row['mhsw_id']; ?>&aksi=hapus">Hapus</a>&nbsp;&nbsp;&nbsp;
                <a href="?mhsw_id=<?php echo $row['mhsw_id']; ?>&aksi=lihat_update">Update</a></td>
 </tr>
 <?php } ?>
 </table>
 