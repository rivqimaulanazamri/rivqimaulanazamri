<?php
class mhsw {
    private $mhsw_id;
    private $mhsw_nim;
    private $mhsw_nama;
    private $mhsw_alamat;

    public function __construct($mhsw_id, $mhsw_nim, $mhsw_nama,$mhsw_alamat) {
        $this->id = $mhsw_id;
        $this->nama = $mhsw_nama;
        $this->contact_info = $contact_info;
    }

    public function getId() {
        return $this->id;
    }
    public function getName() {
        return $this->nama;
    }

    public function getContactInfo() {
        return $this->contact_info;
    }
}
?>
