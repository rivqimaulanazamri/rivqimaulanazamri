<?php
class Product {
    private $id;
    private $nama;
    private $nim;
    private $alamat;
    private $ambilmk;
    private $mk;

    public function __construct($mhsw_id, $mhsw_nim, $mhsw_nama, $mhsw_alamat, $ambilmk, $mk) {
        $this->id = $mhswid;
        $this->nama = $mhsw_nama;
        $this->nim = $primhsw_nim;
        $this->alamat = $mhsw_alamat;
        $this->mk = $mk;
        $this->ambilmk = $ambilmk;
    }

    public function getId() {
        return $this->id;
    }

    public function getName() {
        return $this->nama;
    }

    public function getPrice() {
        return $this->nim;
    }

    public function getDescription() {
        return $this->alamat;
    }

    public function getCategoryId() {
        return $this->mk;
    }

    public function getSupplierId() {
        return $this->ambilmk;
    }
}
?>
