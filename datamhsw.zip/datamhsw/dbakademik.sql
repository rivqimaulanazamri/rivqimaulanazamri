-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2024 at 07:13 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbakademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambilmk`
--

CREATE TABLE `ambilmk` (
  `mhsw_nim` varchar(25) NOT NULL,
  `kodemk` int(5) NOT NULL,
  `smt` int(2) NOT NULL,
  `th_ajar` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ambilmk`
--

INSERT INTO `ambilmk` (`mhsw_nim`, `kodemk`, `smt`, `th_ajar`) VALUES
('232111', 1122, 4, 2024),
('234544', 1133, 4, 2024),
('2233200', 1144, 4, 1024);

-- --------------------------------------------------------

--
-- Table structure for table `mk`
--

CREATE TABLE `mk` (
  `kodemk` int(5) NOT NULL,
  `namamk` text NOT NULL,
  `sks` int(2) NOT NULL,
  `dosen` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mk`
--

INSERT INTO `mk` (`kodemk`, `namamk`, `sks`, `dosen`) VALUES
(1122, 'bahasa inggris', 3, 'dr yuli'),
(1133, 'algorima', 3, 'subur s.kom');

-- --------------------------------------------------------

--
-- Table structure for table `tb_mhsw`
--

CREATE TABLE `tb_mhsw` (
  `mhsw_id` int(11) NOT NULL,
  `mhsw_nim` varchar(25) NOT NULL,
  `mhsw_nama` varchar(100) NOT NULL,
  `mhsw_alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_mhsw`
--

INSERT INTO `tb_mhsw` (`mhsw_id`, `mhsw_nim`, `mhsw_nama`, `mhsw_alamat`) VALUES
(14, '2233200', 'sam', 'klaten'),
(22, '232111', 'lily', 'klaten'),
(25, '234544', 'rohmat', 'sukoharjo'),
(28, '222741', 'yono', 'jakarta'),
(30, '222746', 'rio', 'arab');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambilmk`
--
ALTER TABLE `ambilmk`
  ADD PRIMARY KEY (`kodemk`),
  ADD KEY `mhsw_nim` (`mhsw_nim`);

--
-- Indexes for table `mk`
--
ALTER TABLE `mk`
  ADD KEY `kodemk` (`kodemk`);

--
-- Indexes for table `tb_mhsw`
--
ALTER TABLE `tb_mhsw`
  ADD PRIMARY KEY (`mhsw_id`),
  ADD UNIQUE KEY `mhsw_nim` (`mhsw_nim`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_mhsw`
--
ALTER TABLE `tb_mhsw`
  MODIFY `mhsw_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ambilmk`
--
ALTER TABLE `ambilmk`
  ADD CONSTRAINT `ambilmk_ibfk_1` FOREIGN KEY (`mhsw_nim`) REFERENCES `tb_mhsw` (`mhsw_nim`);

--
-- Constraints for table `mk`
--
ALTER TABLE `mk`
  ADD CONSTRAINT `mk_ibfk_1` FOREIGN KEY (`kodemk`) REFERENCES `ambilmk` (`kodemk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
